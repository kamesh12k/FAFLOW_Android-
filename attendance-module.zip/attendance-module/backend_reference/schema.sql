-- Reference schema for the backend this module syncs with.
-- Run once pgvector extension is available: CREATE EXTENSION IF NOT EXISTS vector;

CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE employees (
    employee_id     TEXT PRIMARY KEY,
    full_name       TEXT NOT NULL,
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE employee_embeddings (
    employee_id     TEXT NOT NULL REFERENCES employees(employee_id) ON DELETE CASCADE,
    embedding_slot  INT NOT NULL,
    embedding       vector(128) NOT NULL,   -- SFace default output dim; adjust if you swap models
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (employee_id, embedding_slot)
);

-- Approximate nearest-neighbor index for fast 1:N matching server-side
-- (useful for audit/re-verification even though the device matches locally).
CREATE INDEX employee_embeddings_ivfflat
    ON employee_embeddings USING ivfflat (embedding vector_cosine_ops)
    WITH (lists = 100);

CREATE TABLE geofence_sites (
    site_id         TEXT PRIMARY KEY,
    name            TEXT NOT NULL,
    latitude        DOUBLE PRECISION NOT NULL,
    longitude       DOUBLE PRECISION NOT NULL,
    radius_meters   REAL NOT NULL DEFAULT 100
);

CREATE TABLE attendance_records (
    server_id               BIGSERIAL PRIMARY KEY,
    client_record_id        BIGINT NOT NULL,   -- Room's local id; idempotency key alongside device_id
    device_id               TEXT NOT NULL,
    employee_id             TEXT NOT NULL REFERENCES employees(employee_id),
    event_type              TEXT NOT NULL CHECK (event_type IN ('CHECK_IN','CHECK_OUT')),
    captured_at             TIMESTAMPTZ NOT NULL,
    latitude                DOUBLE PRECISION NOT NULL,
    longitude               DOUBLE PRECISION NOT NULL,
    location_accuracy_m     REAL NOT NULL,
    site_id                 TEXT REFERENCES geofence_sites(site_id),
    match_confidence        DOUBLE PRECISION NOT NULL,
    liveness_score          REAL NOT NULL,
    received_at             TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (device_id, client_record_id)
);

-- Example nearest-neighbor match query (server-side re-verification):
-- SELECT employee_id, 1 - (embedding <=> $1::vector) AS cosine_similarity
-- FROM employee_embeddings
-- ORDER BY embedding <=> $1::vector
-- LIMIT 5;
