# Geolocation Face-Recognition Attendance Module (Android)

Drop-in Kotlin module implementing your chosen stack:
YuNet (detection) + SFace (recognition) + Silent-Face-Anti-Spoofing (liveness)
+ FusedLocationProviderClient geofencing + Room (offline queue) + WorkManager
(sync) + Retrofit (backend calls to your Postgres+pgvector service).

## 1. Copy files into your project

Copy everything under `src/main/java/com/example/attendance/` into your
app's source tree. **Rename the package** from `com.example.attendance` to
match your app (e.g. `com.yourcompany.yourapp.attendance`) — use Android
Studio's "Refactor > Rename Package" after copying so all imports update
automatically.

```
your-app/
└── app/src/main/java/com/yourcompany/yourapp/
    └── attendance/
        ├── camera/FaceCaptureActivity.kt
        ├── detection/YuNetFaceDetector.kt
        ├── recognition/SFaceRecognizer.kt
        ├── liveness/LivenessDetector.kt
        ├── location/GeofenceLocationValidator.kt
        ├── data/ (Entities.kt, AttendanceDao.kt, AttendanceDatabase.kt)
        ├── sync/ (ApiService.kt, ApiClient.kt, AttendanceSyncWorker.kt)
        ├── repository/ (AttendanceRepository.kt, EnrollmentRepository.kt)
        └── util/ (AttendanceConfig.kt, ImageUtils.kt, DeviceIntegrityGuard.kt)
```

## 2. Merge Gradle + Manifest

- Merge `build.gradle.kts.SNIPPET` into your app module's `build.gradle.kts`.
  Apply the KSP plugin at the top if not already present:
  `plugins { id("com.google.devtools.ksp") }` (match the KSP version to your Kotlin version).
- Merge `AndroidManifest.xml.SNIPPET` into your `AndroidManifest.xml`.

## 3. Add the three ONNX models

Place these in `app/src/main/assets/models/`:
- `yunet.onnx` — export from [OpenCV Zoo YuNet](https://github.com/opencv/opencv_zoo/tree/main/models/face_detection_yunet)
- `sface.onnx` — export from [OpenCV Zoo SFace](https://github.com/opencv/opencv_zoo/tree/main/models/face_recognition_sface)
- `anti_spoof_fourier.onnx` — export from [Silent-Face-Anti-Spoofing](https://github.com/minivision-ai/Silent-Face-Anti-Spoofing) (convert the provided PyTorch checkpoint to ONNX; see that repo's conversion script)

If your ONNX export's output tensor layout differs from the assumptions in
`YuNetFaceDetector.decodeOutputs()` or `LivenessDetector.check()` (class
ordering, single vs multi-output), open the model in [Netron](https://netron.app)
and adjust those two functions accordingly — this is the one spot that's
genuinely model-specific and can't be fully generalized in advance.

## 4. Interaction model: single tap, ~1 second, no face movements

- The user taps **Check In** or **Check Out**. That single tap captures
  exactly one camera frame and runs the pipeline once — there's no
  continuous scanning loop and no waiting for the user to move.
- Liveness is a **single-frame passive check** (Fourier-spectrum spoof
  detection). No blink/head-turn/smile prompt is shown by default.
- Location is **pre-warmed continuously** from the moment the capture
  screen opens (`repository.startPrewarm()`), so at tap-time the geofence
  check is an instant in-memory comparison, not a GPS wait — this is what
  keeps the whole flow inside budget, since a cold GPS fix alone can take
  several seconds.
- End-to-end target is **~1 second** (`AttendanceConfig.PIPELINE_TIME_BUDGET_MS`).
  `AttendanceResult.Success.elapsedMs` reports actual time so you can
  monitor this in the field. If you're missing budget on real devices:
  1. Confirm ONNX Runtime is using the NNAPI or GPU execution provider,
     not falling back to plain CPU.
  2. Lower `DETECT_INPUT_W`/`DETECT_INPUT_H` (e.g. 240x240) — detection is
     usually the biggest single cost.
  3. Double check nothing re-introduces a multi-frame loop; the design here
     is strictly one tap → one frame → one decision.

## 5. Wire it up

**Enroll employees** (once, e.g. from an HR admin flow or on-device kiosk):
```kotlin
val enrollment = EnrollmentRepository(context)
val result = enrollment.enroll(bitmap, employeeId = "E123", employeeName = "Asha K", embeddingSlot = 0)
enrollment.close()
```

**Capture attendance**: launch the Activity with no extra to show both
"Check In" / "Check Out" buttons and let the user pick:
```kotlin
startActivity(Intent(this, FaceCaptureActivity::class.java))
```
Or pre-set the event type (e.g. if your app already knows it's a check-in
flow) to skip the buttons and auto-capture on the first frame:
```kotlin
val intent = Intent(this, FaceCaptureActivity::class.java).apply {
    putExtra(FaceCaptureActivity.EXTRA_EVENT_TYPE, "CHECK_IN")
}
startActivity(intent)
```

**Start background sync** (once, e.g. in `Application.onCreate()` or after login):
```kotlin
AttendanceSyncScheduler.schedulePeriodic(applicationContext)
```

**Point Retrofit at your backend**: edit `BASE_URL` in `ApiClient.kt`, and
implement the two endpoints it expects (`POST /api/v1/attendance/batch`,
`GET /api/v1/embeddings`) against your Postgres+pgvector service —
`backend_reference/schema.sql` gives you the matching table shapes and an
example pgvector nearest-neighbor query.

## 6. Tune thresholds

Everything tunable lives in `AttendanceConfig.kt`:
match confidence, liveness threshold, geofence radius, location staleness/
accuracy limits, sync batch size. Start with the defaults, then tighten
`MATCH_COSINE_THRESHOLD` upward if you see false-accepts in your specific
lighting/camera conditions.

## 7. Privacy / DPDP Act considerations (India)

Since this handles biometric (face) and location data:
- Get explicit, specific consent before enrollment — biometric data is
  "sensitive personal data" under most frameworks including India's DPDP Act.
- Store only embeddings, not raw photos, wherever your workflow allows
  (this module's `AttendanceRecord.photoLocalPath` is nullable and unused
  by default — only wire up photo storage if there's a specific business
  need, and if you do, encrypt it and set a retention/deletion policy).
- Encrypt the local Room database at rest if your compliance review
  requires DB-level encryption beyond full-disk encryption (see the
  comment in `AttendanceDatabase.kt` re: SQLCipher).
- Provide a data-deletion path: `AttendanceDao.deleteEmbeddingsForEmployee()`
  is already there for offboarding; make sure your backend deletes the
  corresponding pgvector rows too.
- Log a clear audit trail of consent capture and enrollment/deletion events
  — DPDP requires the ability to show what data you hold and why.

This module gives you the technical scaffolding; the consent flows, privacy
notice, and retention policy are organizational/legal decisions your team
needs to make and I'm not best placed to draft the compliance language.

## 8. What's intentionally left for you to finish

- **UI polish**: `FaceCaptureActivity` uses a bare-bones programmatic layout
  so it drops in without an XML dependency — swap in your own designed screen.
- **Auth**: `AuthTokenStore` is a placeholder reading SharedPreferences —
  wire it to your real session/auth module.
- **Site list loading**: `approvedSites` in `FaceCaptureActivity` is
  hardcoded — load it from your backend or local config instead.
- **Active liveness challenge** (not used by default, since you asked for
  no face movements): the passive Fourier-spectrum check catches most
  photo/video-replay attacks in a single frame. If a future security
  review decides that's not enough, `LivenessDetector.randomChallenge()`
  is an unused hook you can wire into the UI for a blink/head-turn prompt —
  understand that adds latency and user friction, so it's a genuine
  trade-off against the current speed goal, not a free upgrade.
