package com.example.attendance.camera

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.example.attendance.location.GeofenceSite
import com.example.attendance.repository.AttendanceRepository
import com.example.attendance.repository.AttendanceResult
import com.example.attendance.util.ImageUtils
import kotlinx.coroutines.launch
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/**
 * Single-tap attendance capture screen.
 *
 * Flow: preview runs continuously (so the user can frame their face), but
 * NOTHING is analyzed until the user taps "Check In" or "Check Out". At
 * that instant we grab exactly the next available camera frame, run the
 * pipeline once, and show the result — target end-to-end time is ~1 second.
 * There is no waiting for a blink/head-turn/smile: liveness is a single
 * passive frame check (see LivenessDetector), so nothing extra is asked
 * of the user.
 *
 * Location is pre-warmed the moment this screen opens (repository.startPrewarm())
 * so the geofence check at tap-time is instant instead of waiting on GPS.
 */
class FaceCaptureActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_EVENT_TYPE = "extra_event_type" // optional pre-set; else user picks a button
        private const val TAG = "FaceCaptureActivity"
    }

    private lateinit var previewView: PreviewView
    private lateinit var statusText: TextView
    private lateinit var checkInButton: Button
    private lateinit var checkOutButton: Button
    private lateinit var cameraExecutor: ExecutorService
    private lateinit var repository: AttendanceRepository

    private val isProcessing = AtomicBoolean(false)
    /** Set by a button tap; the very next analyzed frame consumes it and clears it.
     *  null = no capture pending, camera frames are simply dropped (cheap). */
    private val pendingEventType = AtomicReference<String?>(null)

    // TODO: replace with sites loaded from your backend / local config
    private val approvedSites = listOf(
        GeofenceSite(siteId = "hq", name = "Head Office", latitude = 11.0168, longitude = 76.9558, radiusMeters = 100f)
    )

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        val cameraGranted = grants[Manifest.permission.CAMERA] == true
        val locationGranted = grants[Manifest.permission.ACCESS_FINE_LOCATION] == true
        if (cameraGranted && locationGranted) {
            startCamera()
            repository.startPrewarm()
        } else {
            Toast.makeText(this, "Camera and location permissions are required for attendance", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Minimal programmatic layout — swap for your own designed screen.
        previewView = PreviewView(this)
        statusText = TextView(this).apply {
            text = "Center your face and tap Check In or Check Out"
            gravity = Gravity.CENTER
            setPadding(24, 24, 24, 24)
        }
        checkInButton = Button(this).apply { text = "Check In" }
        checkOutButton = Button(this).apply { text = "Check Out" }

        val buttonRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            addView(checkInButton, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(checkOutButton, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(previewView, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(statusText)
            addView(buttonRow)
        }
        setContentView(root)

        repository = AttendanceRepository(applicationContext)
        cameraExecutor = Executors.newSingleThreadExecutor()

        checkInButton.setOnClickListener { requestCapture("CHECK_IN") }
        checkOutButton.setOnClickListener { requestCapture("CHECK_OUT") }

        // If the caller pre-set an event type via intent extra, skip the
        // buttons entirely and auto-capture on the first available frame.
        intent.getStringExtra(EXTRA_EVENT_TYPE)?.let { presetType ->
            buttonRow.visibility = android.view.View.GONE
            pendingEventType.set(presetType)
        }

        if (hasPermissions()) {
            startCamera()
            repository.startPrewarm()
        } else {
            permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.ACCESS_FINE_LOCATION))
        }
    }

    private fun requestCapture(eventType: String) {
        if (isProcessing.get()) return // ignore double-taps mid-pipeline
        statusText.text = "Verifying..."
        pendingEventType.set(eventType)
    }

    private fun hasPermissions(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()

            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }

            // STRATEGY_KEEP_ONLY_LATEST: cheap to leave running since we no-op
            // every frame until a button tap sets pendingEventType.
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also { it.setAnalyzer(cameraExecutor, ::analyzeFrame) }

            val selector = CameraSelector.DEFAULT_FRONT_CAMERA

            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, selector, preview, analysis)
            } catch (e: Exception) {
                Log.e(TAG, "Camera bind failed", e)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    /** Runs on cameraExecutor for every camera frame, but is a cheap no-op
     *  (just checks an AtomicReference) unless a button tap is pending —
     *  this is what makes the pipeline single-shot rather than continuous. */
    private fun analyzeFrame(imageProxy: ImageProxy) {
        val eventType = pendingEventType.get()
        if (eventType == null || !isProcessing.compareAndSet(false, true)) {
            imageProxy.close()
            return
        }
        pendingEventType.set(null) // consume — only this one frame is processed

        val bitmap = try {
            ImageUtils.imageProxyToBitmap(imageProxy)
        } catch (e: Exception) {
            imageProxy.close()
            isProcessing.set(false)
            return
        }
        imageProxy.close()

        lifecycleScope.launch {
            val result = repository.markAttendance(bitmap, approvedSites, eventType)
            runOnUiThread { handleResult(result, eventType) }
            isProcessing.set(false)
        }
    }

    private fun handleResult(result: AttendanceResult, eventType: String) {
        when (result) {
            is AttendanceResult.Success -> {
                statusText.text = "✅ ${result.employeeName} marked ${eventType} " +
                    "(confidence ${"%.2f".format(result.confidence)}, ${result.elapsedMs}ms)"
                // TODO: auto-finish() after a short delay, or wait for user to tap "Done"
            }
            is AttendanceResult.NoFaceDetected -> statusText.text = "No face detected — center your face and try again"
            is AttendanceResult.LivenessFailed -> statusText.text = "⚠️ Liveness check failed — please use the live camera"
            is AttendanceResult.NoMatch -> statusText.text = "Face not recognized. Contact HR if you're enrolled."
            is AttendanceResult.OutsideGeofence -> statusText.text =
                "❌ You're ${result.distanceMeters.toInt()}m from ${result.nearestSiteName ?: "the site"} — move closer"
            is AttendanceResult.LocationRejected -> statusText.text = "❌ ${result.reason}"
            is AttendanceResult.DeviceFlagged -> statusText.text = "❌ ${result.reason}"
            is AttendanceResult.Error -> {
                Log.e(TAG, "Pipeline error", result.throwable)
                statusText.text = "Something went wrong — please try again"
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        repository.close()
        cameraExecutor.shutdown()
    }
}
