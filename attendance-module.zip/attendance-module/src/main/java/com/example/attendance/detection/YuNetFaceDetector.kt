package com.example.attendance.detection

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import com.example.attendance.util.AttendanceConfig
import java.nio.FloatBuffer
import kotlin.math.max
import kotlin.math.min

data class DetectedFace(
    val box: Rect,
    val score: Float,
    /** 5-point landmarks in ORIGINAL bitmap coordinates: [lx,ly, rx,ry, nx,ny, mlx,mly, mrx,mry] */
    val landmarks: FloatArray
)

/**
 * Wraps the YuNet face detector (OpenCV Zoo, ONNX export) via ONNX Runtime Mobile.
 * Input: BGR, 320x320 (configurable), values 0-255 float32, NCHW.
 * Output tensors follow the standard YuNet ONNX export: loc/conf/iou decoded into
 * boxes + 5-point landmarks + score, already NMS'd if using the packaged post-proc
 * variant; here we do a light manual NMS to be robust to either export flavor.
 */
class YuNetFaceDetector(context: Context) : AutoCloseable {

    private val env = OrtEnvironment.getEnvironment()
    private val session: OrtSession

    init {
        val modelBytes = context.assets.open(AttendanceConfig.ASSET_YUNET).readBytes()
        val options = OrtSession.SessionOptions().apply {
            setIntraOpNumThreads(4)
            // addNnapi() // uncomment if your ORT build includes the NNAPI EP for extra speed
        }
        session = env.createSession(modelBytes, options)
    }

    fun detect(bitmap: Bitmap): List<DetectedFace> {
        val inputW = AttendanceConfig.DETECT_INPUT_W
        val inputH = AttendanceConfig.DETECT_INPUT_H
        val resized = Bitmap.createScaledBitmap(bitmap, inputW, inputH, true)
        val scaleX = bitmap.width.toFloat() / inputW
        val scaleY = bitmap.height.toFloat() / inputH

        val inputBuffer = bitmapToChwFloatBuffer(resized)
        val inputName = session.inputNames.iterator().next()
        val tensor = OnnxTensor.createTensor(
            env, inputBuffer, longArrayOf(1, 3, inputH.toLong(), inputW.toLong())
        )

        tensor.use {
            session.run(mapOf(inputName to it)).use { results ->
                return decodeOutputs(results, scaleX, scaleY)
            }
        }
    }

    /** Decodes raw model output into face boxes. Adjust output-name indices to match
     *  the exact YuNet ONNX export you bundle (loc/conf/iou vs a single fused output). */
    private fun decodeOutputs(
        results: OrtSession.Result,
        scaleX: Float,
        scaleY: Float
    ): List<DetectedFace> {
        // Most YuNet ONNX Zoo exports emit a single [N, 15] tensor per detection:
        // [x, y, w, h, lx1,ly1, lx2,ly2, lx3,ly3, lx4,ly4, lx5,ly5, score]
        val raw = results[0].value as Array<*>
        val detections = mutableListOf<DetectedFace>()

        @Suppress("UNCHECKED_CAST")
        val rows = raw[0] as Array<FloatArray>

        for (row in rows) {
            val score = row[14]
            if (score < AttendanceConfig.DETECT_SCORE_THRESHOLD) continue
            val x = row[0] * scaleX
            val y = row[1] * scaleY
            val w = row[2] * scaleX
            val h = row[3] * scaleY
            val landmarks = FloatArray(10)
            for (i in 0 until 5) {
                landmarks[2 * i] = row[4 + 2 * i] * scaleX
                landmarks[2 * i + 1] = row[4 + 2 * i + 1] * scaleY
            }
            val box = Rect(x.toInt(), y.toInt(), (x + w).toInt(), (y + h).toInt())
            detections.add(DetectedFace(box, score, landmarks))
        }
        return nms(detections, AttendanceConfig.DETECT_NMS_THRESHOLD)
            .take(AttendanceConfig.DETECT_TOP_K)
    }

    private fun nms(faces: List<DetectedFace>, iouThreshold: Float): List<DetectedFace> {
        val sorted = faces.sortedByDescending { it.score }.toMutableList()
        val kept = mutableListOf<DetectedFace>()
        while (sorted.isNotEmpty()) {
            val best = sorted.removeAt(0)
            kept.add(best)
            sorted.removeAll { iou(best.box, it.box) > iouThreshold }
        }
        return kept
    }

    private fun iou(a: Rect, b: Rect): Float {
        val interLeft = max(a.left, b.left)
        val interTop = max(a.top, b.top)
        val interRight = min(a.right, b.right)
        val interBottom = min(a.bottom, b.bottom)
        val interArea = max(0, interRight - interLeft) * max(0, interBottom - interTop)
        val union = a.width() * a.height() + b.width() * b.height() - interArea
        return if (union <= 0) 0f else interArea.toFloat() / union
    }

    private fun bitmapToChwFloatBuffer(bitmap: Bitmap): FloatBuffer {
        val w = bitmap.width
        val h = bitmap.height
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)

        val buffer = FloatBuffer.allocate(3 * w * h)
        // Fill channel-major (B,G,R) to match OpenCV's default BGR training convention.
        val bPlane = FloatArray(w * h)
        val gPlane = FloatArray(w * h)
        val rPlane = FloatArray(w * h)
        for (i in pixels.indices) {
            val p = pixels[i]
            rPlane[i] = ((p shr 16) and 0xFF).toFloat()
            gPlane[i] = ((p shr 8) and 0xFF).toFloat()
            bPlane[i] = (p and 0xFF).toFloat()
        }
        buffer.put(bPlane); buffer.put(gPlane); buffer.put(rPlane)
        buffer.rewind()
        return buffer
    }

    override fun close() {
        session.close()
    }
}
