package com.example.attendance.recognition

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.graphics.Bitmap
import com.example.attendance.util.AttendanceConfig
import java.nio.FloatBuffer

/**
 * Wraps the SFace recognition model (OpenCV Zoo, ONNX export) to produce a
 * 128-d L2-normalized embedding from a 112x112 ALIGNED face crop.
 * Use ImageUtils.alignFace(...) with YuNet's 5-point landmarks before calling embed().
 */
class SFaceRecognizer(context: Context) : AutoCloseable {

    private val env = OrtEnvironment.getEnvironment()
    private val session: OrtSession

    init {
        val modelBytes = context.assets.open(AttendanceConfig.ASSET_SFACE).readBytes()
        val options = OrtSession.SessionOptions().apply { setIntraOpNumThreads(4) }
        session = env.createSession(modelBytes, options)
    }

    fun embed(alignedFace112: Bitmap): FloatArray {
        require(alignedFace112.width == AttendanceConfig.RECOGNITION_INPUT_SIZE &&
                alignedFace112.height == AttendanceConfig.RECOGNITION_INPUT_SIZE) {
            "SFace expects a ${AttendanceConfig.RECOGNITION_INPUT_SIZE}x${AttendanceConfig.RECOGNITION_INPUT_SIZE} aligned crop"
        }
        val inputName = session.inputNames.iterator().next()
        val buffer = bitmapToChwFloatBuffer(alignedFace112)
        val size = AttendanceConfig.RECOGNITION_INPUT_SIZE.toLong()
        val tensor = OnnxTensor.createTensor(env, buffer, longArrayOf(1, 3, size, size))

        tensor.use {
            session.run(mapOf(inputName to it)).use { results ->
                @Suppress("UNCHECKED_CAST")
                val output = (results[0].value as Array<FloatArray>)[0]
                return l2Normalize(output)
            }
        }
    }

    /** Returns cosine similarity between two embeddings; compare against
     *  AttendanceConfig.MATCH_COSINE_THRESHOLD to decide a match. */
    fun similarity(a: FloatArray, b: FloatArray): Double {
        var dot = 0.0
        for (i in a.indices) dot += a[i] * b[i]
        return dot // both already L2-normalized, so dot == cosine similarity
    }

    private fun l2Normalize(v: FloatArray): FloatArray {
        var sumSq = 0.0
        for (x in v) sumSq += x * x
        val norm = Math.sqrt(sumSq).toFloat().coerceAtLeast(1e-10f)
        return FloatArray(v.size) { v[it] / norm }
    }

    private fun bitmapToChwFloatBuffer(bitmap: Bitmap): FloatBuffer {
        val w = bitmap.width
        val h = bitmap.height
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)

        val buffer = FloatBuffer.allocate(3 * w * h)
        val bPlane = FloatArray(w * h)
        val gPlane = FloatArray(w * h)
        val rPlane = FloatArray(w * h)
        for (i in pixels.indices) {
            val p = pixels[i]
            rPlane[i] = ((p shr 16) and 0xFF).toFloat()
            gPlane[i] = ((p shr 8) and 0xFF).toFloat()
            bPlane[i] = (p and 0xFF).toFloat()
        }
        buffer.put(bPlane); buffer.put(gPlane); buffer.put(rPlane)
        buffer.rewind()
        return buffer
    }

    override fun close() {
        session.close()
    }
}
