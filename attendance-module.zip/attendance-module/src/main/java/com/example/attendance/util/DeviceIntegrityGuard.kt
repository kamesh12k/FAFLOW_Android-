package com.example.attendance.util

import android.content.Context
import android.provider.Settings
import com.scottyab.rootbeer.RootBeer

/**
 * Cheap, open-source device-trust signal. Not a hard security boundary
 * (RootBeer can be bypassed), but useful to flag suspicious devices in your
 * backend for manual review, or to block attendance marking outright per
 * your org's policy.
 */
object DeviceIntegrityGuard {

    fun isDeviceSuspicious(context: Context): Boolean {
        val rootBeer = RootBeer(context)
        return rootBeer.isRooted
    }

    fun stableDeviceId(context: Context): String =
        Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown-device"
}
