package com.example.attendance.util

import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.Rect
import androidx.camera.core.ImageProxy
import java.io.ByteArrayOutputStream
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Rect as GRect
import android.graphics.YuvImage
import kotlin.math.max
import kotlin.math.min

object ImageUtils {

    /** Converts a CameraX ImageProxy (YUV_420_888) to an upright Bitmap. */
    fun imageProxyToBitmap(image: ImageProxy): Bitmap {
        val yBuffer = image.planes[0].buffer
        val uBuffer = image.planes[1].buffer
        val vBuffer = image.planes[2].buffer

        val ySize = yBuffer.remaining()
        val uSize = uBuffer.remaining()
        val vSize = vBuffer.remaining()

        val nv21 = ByteArray(ySize + uSize + vSize)
        yBuffer.get(nv21, 0, ySize)
        vBuffer.get(nv21, ySize, vSize)
        uBuffer.get(nv21, ySize + vSize, uSize)

        val yuvImage = YuvImage(nv21, ImageFormat.NV21, image.width, image.height, null)
        val out = ByteArrayOutputStream()
        yuvImage.compressToJpeg(GRect(0, 0, image.width, image.height), 90, out)
        val bytes = out.toByteArray()
        val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)

        val rotation = image.imageInfo.rotationDegrees
        return if (rotation != 0) rotateBitmap(bitmap, rotation) else bitmap
    }

    fun rotateBitmap(src: Bitmap, degrees: Int): Bitmap {
        val matrix = Matrix().apply { postRotate(degrees.toFloat()) }
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, matrix, true)
    }

    /** Crops a face box out of the full frame with a safety margin, clamped to bounds. */
    fun cropWithMargin(src: Bitmap, box: Rect, marginRatio: Float = 0.2f): Bitmap {
        val marginX = (box.width() * marginRatio).toInt()
        val marginY = (box.height() * marginRatio).toInt()
        val left = max(0, box.left - marginX)
        val top = max(0, box.top - marginY)
        val right = min(src.width, box.right + marginX)
        val bottom = min(src.height, box.bottom + marginY)
        return Bitmap.createBitmap(src, left, top, right - left, bottom - top)
    }

    /**
     * Aligns a face crop to a canonical 112x112 pose using 5-point landmarks
     * (left eye, right eye, nose tip, left mouth corner, right mouth corner),
     * matching the reference coordinates SFace was trained on. Falls back to
     * a plain resize if landmarks aren't available.
     */
    fun alignFace(
        src: Bitmap,
        landmarks: FloatArray?, // [lx,ly, rx,ry, nx,ny, mlx,mly, mrx,mry] in src coordinates, or null
        outputSize: Int = 112
    ): Bitmap {
        if (landmarks == null || landmarks.size < 10) {
            return Bitmap.createScaledBitmap(src, outputSize, outputSize, true)
        }
        // Reference landmark positions for a 112x112 aligned crop (ArcFace/SFace standard).
        val ref = floatArrayOf(
            38.2946f, 51.6963f,
            73.5318f, 51.5014f,
            56.0252f, 71.7366f,
            41.5493f, 92.3655f,
            70.7299f, 92.2041f
        )
        val srcPts = FloatArray(10) { landmarks[it] }
        val matrix = similarityTransform(srcPts, ref)
        val out = Bitmap.createBitmap(outputSize, outputSize, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(out)
        val paint = android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG)
        canvas.drawBitmap(src, matrix, paint)
        return out
    }

    /** Least-squares similarity (rotation+scale+translation) transform src->dst. */
    private fun similarityTransform(src: FloatArray, dst: FloatArray): Matrix {
        val n = src.size / 2
        var srcMeanX = 0f; var srcMeanY = 0f
        var dstMeanX = 0f; var dstMeanY = 0f
        for (i in 0 until n) {
            srcMeanX += src[2 * i]; srcMeanY += src[2 * i + 1]
            dstMeanX += dst[2 * i]; dstMeanY += dst[2 * i + 1]
        }
        srcMeanX /= n; srcMeanY /= n; dstMeanX /= n; dstMeanY /= n

        var sxx = 0f; var syy = 0f; var sxy = 0f; var syx = 0f
        var srcVar = 0f
        for (i in 0 until n) {
            val sx = src[2 * i] - srcMeanX
            val sy = src[2 * i + 1] - srcMeanY
            val dx = dst[2 * i] - dstMeanX
            val dy = dst[2 * i + 1] - dstMeanY
            sxx += sx * dx; syy += sy * dy
            sxy += sx * dy; syx += sy * dx
            srcVar += sx * sx + sy * sy
        }
        val a = (sxx + syy) / srcVar
        val b = (sxy - syx) / srcVar
        val tx = dstMeanX - (a * srcMeanX - b * srcMeanY)
        val ty = dstMeanY - (b * srcMeanX + a * srcMeanY)

        val matrix = Matrix()
        // Matrix.setValues expects row-major [MSCALE_X, MSKEW_X, MTRANS_X, MSKEW_Y, MSCALE_Y, MTRANS_Y, ...]
        matrix.setValues(floatArrayOf(a, -b, tx, b, a, ty, 0f, 0f, 1f))
        return matrix
    }

    fun cosineSimilarity(a: FloatArray, b: FloatArray): Double {
        var dot = 0.0; var na = 0.0; var nb = 0.0
        for (i in a.indices) {
            dot += a[i] * b[i]
            na += a[i] * a[i]
            nb += b[i] * b[i]
        }
        if (na == 0.0 || nb == 0.0) return 0.0
        return dot / (Math.sqrt(na) * Math.sqrt(nb))
    }
}
