package com.example.attendance.location

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import androidx.core.content.ContextCompat
import com.example.attendance.util.AttendanceConfig
import com.google.android.gms.location.*
import kotlin.math.*

data class GeofenceSite(
    val siteId: String,
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val radiusMeters: Float = AttendanceConfig.DEFAULT_GEOFENCE_RADIUS_METERS
)

sealed class LocationCheckResult {
    data class Inside(val site: GeofenceSite, val distanceMeters: Float, val location: Location) : LocationCheckResult()
    data class Outside(val nearestSite: GeofenceSite?, val distanceMeters: Float, val location: Location) : LocationCheckResult()
    data class Rejected(val reason: String) : LocationCheckResult()
}

/**
 * SPEED-CRITICAL PATH: a cold `getCurrentLocation()` call can take several
 * seconds to get a GPS lock, which alone would blow a 1-second check-in
 * budget. Instead this class keeps a continuously-updated location cached
 * in memory (via requestLocationUpdates) from the moment the capture screen
 * opens, so by the time the user taps Check In / Check Out, validation is
 * just an in-memory freshness + distance check — no network/GPS wait.
 *
 * Call startContinuousUpdates() when your capture screen opens (or even
 * earlier, e.g. when the app comes to foreground) and stopContinuousUpdates()
 * when it closes.
 */
class GeofenceLocationValidator(private val context: Context) {

    private val fusedClient = LocationServices.getFusedLocationProviderClient(context)
    private var callback: LocationCallback? = null

    @Volatile
    private var cachedLocation: Location? = null

    fun hasLocationPermission(): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    fun startContinuousUpdates() {
        if (!hasLocationPermission() || callback != null) return

        val request = LocationRequest.Builder(
            Priority.PRIORITY_HIGH_ACCURACY,
            AttendanceConfig.LOCATION_UPDATE_INTERVAL_MS
        ).setMinUpdateIntervalMillis(AttendanceConfig.LOCATION_UPDATE_INTERVAL_MS / 2).build()

        // Seed immediately with whatever the OS already has cached, so even
        // the very first frame after screen-open has *something* to check.
        fusedClient.lastLocation.addOnSuccessListener { loc -> loc?.let { cachedLocation = it } }

        callback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                result.lastLocation?.let { cachedLocation = it }
            }
        }
        fusedClient.requestLocationUpdates(request, callback!!, context.mainLooper)
    }

    fun stopContinuousUpdates() {
        callback?.let { fusedClient.removeLocationUpdates(it) }
        callback = null
    }

    /**
     * Synchronous, instant check against the pre-warmed cached location.
     * No suspend, no network/GPS wait — this is what makes the check-in
     * path fit inside a ~1 second budget. Call startContinuousUpdates()
     * early enough (screen open) that a fix is already cached by tap-time.
     */
    fun validateAgainstSitesFast(sites: List<GeofenceSite>): LocationCheckResult {
        if (!hasLocationPermission()) return LocationCheckResult.Rejected("Location permission not granted")

        val location = cachedLocation
            ?: return LocationCheckResult.Rejected("No location fix yet — try again in a moment")

        val ageMs = System.currentTimeMillis() - location.time
        if (ageMs > AttendanceConfig.LOCATION_MAX_AGE_MS) {
            return LocationCheckResult.Rejected("Location fix too old (${ageMs}ms) — try again")
        }
        if (location.accuracy > AttendanceConfig.LOCATION_MIN_ACCURACY_METERS) {
            return LocationCheckResult.Rejected("Location accuracy too poor (${location.accuracy}m)")
        }
        if (isMockLocation(location)) {
            return LocationCheckResult.Rejected("Mock/fake location detected")
        }

        var nearest: GeofenceSite? = null
        var nearestDistance = Float.MAX_VALUE
        for (site in sites) {
            val d = haversineMeters(location.latitude, location.longitude, site.latitude, site.longitude)
            if (d < nearestDistance) {
                nearestDistance = d
                nearest = site
            }
            if (d <= site.radiusMeters) {
                return LocationCheckResult.Inside(site, d, location)
            }
        }
        return LocationCheckResult.Outside(nearest, nearestDistance, location)
    }

    private fun isMockLocation(location: Location): Boolean =
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
            location.isMock
        } else {
            @Suppress("DEPRECATION")
            location.isFromMockProvider
        }

    private fun haversineMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Float {
        val r = 6371000.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2).pow(2) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2).pow(2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return (r * c).toFloat()
    }
}
