package com.example.attendance.sync

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

data class AttendanceUploadDto(
    val employeeId: String,
    val eventType: String,
    val capturedAtEpochMs: Long,
    val latitude: Double,
    val longitude: Double,
    val locationAccuracyMeters: Float,
    val siteId: String?,
    val matchConfidence: Double,
    val livenessScore: Float,
    val deviceId: String,
    val clientRecordId: Long // local Room id, lets backend dedupe on retry
)

data class AttendanceUploadResponse(
    val serverId: String,
    val clientRecordId: Long,
    val status: String
)

data class EmployeeEmbeddingDto(
    val employeeId: String,
    val employeeName: String,
    val embeddingSlot: Int,
    val embedding: FloatArray,
    val updatedAtEpochMs: Long
)

interface AttendanceApiService {

    /** Pushes one batch of pending attendance records. Backend should upsert
     *  into Postgres and treat clientRecordId as an idempotency key. */
    @POST("api/v1/attendance/batch")
    suspend fun uploadAttendanceBatch(
        @Body records: List<AttendanceUploadDto>
    ): Response<List<AttendanceUploadResponse>>

    /** Pulls the current enrolled-employee embedding set (pgvector-backed)
     *  so the device can match fully offline. Use `since` for incremental sync. */
    @GET("api/v1/embeddings")
    suspend fun getEmbeddings(
        @Query("since") sinceEpochMs: Long
    ): Response<List<EmployeeEmbeddingDto>>
}
