package com.example.attendance.sync

import android.content.Context
import androidx.work.*
import com.example.attendance.data.AttendanceDatabase
import com.example.attendance.data.EmployeeEmbedding
import com.example.attendance.util.AttendanceConfig
import java.util.concurrent.TimeUnit

/**
 * Two-way sync, run whenever connectivity is available:
 *  1) UPLOAD: drain locally-queued attendance marks to the backend.
 *  2) DOWNLOAD: refresh the on-device embedding cache so 1:N face matching
 *     keeps working offline for newly-enrolled or updated employees.
 *
 * Enqueue via AttendanceSyncScheduler below rather than constructing directly.
 */
class AttendanceSyncWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val dao = AttendanceDatabase.getInstance(applicationContext).attendanceDao()
        val api = ApiClient.create { AuthTokenStore.getToken(applicationContext) }

        val uploadOk = uploadPendingRecords(dao, api)
        val downloadOk = refreshEmbeddingCache(dao, api)

        return if (uploadOk && downloadOk) Result.success() else Result.retry()
    }

    private suspend fun uploadPendingRecords(
        dao: com.example.attendance.data.AttendanceDao,
        api: AttendanceApiService
    ): Boolean {
        return try {
            val pending = dao.getUnsyncedBatch(AttendanceConfig.SYNC_BATCH_SIZE)
            if (pending.isEmpty()) return true

            val dtos = pending.map {
                AttendanceUploadDto(
                    employeeId = it.employeeId,
                    eventType = it.eventType,
                    capturedAtEpochMs = it.capturedAtEpochMs,
                    latitude = it.latitude,
                    longitude = it.longitude,
                    locationAccuracyMeters = it.locationAccuracyMeters,
                    siteId = it.siteId,
                    matchConfidence = it.matchConfidence,
                    livenessScore = it.livenessScore,
                    deviceId = it.deviceId,
                    clientRecordId = it.id
                )
            }

            val response = api.uploadAttendanceBatch(dtos)
            if (response.isSuccessful) {
                response.body()?.forEach { result ->
                    if (result.status == "OK") dao.markSynced(result.clientRecordId)
                }
                true
            } else {
                pending.forEach { dao.recordSyncFailure(it.id, "HTTP ${response.code()}") }
                false
            }
        } catch (e: Exception) {
            false
        }
    }

    private suspend fun refreshEmbeddingCache(
        dao: com.example.attendance.data.AttendanceDao,
        api: AttendanceApiService
    ): Boolean {
        return try {
            val lastSync = SyncPrefs.getLastEmbeddingSync(applicationContext)
            val response = api.getEmbeddings(lastSync)
            if (!response.isSuccessful) return false

            val dtos = response.body() ?: emptyList()
            if (dtos.isNotEmpty()) {
                dao.upsertEmbeddings(dtos.map {
                    EmployeeEmbedding(
                        employeeId = it.employeeId,
                        embeddingSlot = it.embeddingSlot,
                        employeeName = it.employeeName,
                        embedding = it.embedding,
                        updatedAtEpochMs = it.updatedAtEpochMs
                    )
                })
            }
            SyncPrefs.setLastEmbeddingSync(applicationContext, System.currentTimeMillis())
            true
        } catch (e: Exception) {
            false
        }
    }

    companion object {
        const val UNIQUE_WORK_NAME = "attendance_sync_work"
    }
}

/** Public entry point: call this from Application.onCreate() or after login. */
object AttendanceSyncScheduler {

    fun schedulePeriodic(context: Context) {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        val request = PeriodicWorkRequestBuilder<AttendanceSyncWorker>(15, TimeUnit.MINUTES)
            .setConstraints(constraints)
            .setBackoffCriteria(
                BackoffPolicy.EXPONENTIAL,
                AttendanceConfig.SYNC_RETRY_BACKOFF_MIN,
                TimeUnit.MINUTES
            )
            .build()

        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            AttendanceSyncWorker.UNIQUE_WORK_NAME,
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }

    /** Call this right after a new attendance mark is saved locally, so it
     *  uploads promptly if connectivity is already available, instead of
     *  waiting for the next periodic tick. */
    fun triggerImmediateSync(context: Context) {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()
        val request = OneTimeWorkRequestBuilder<AttendanceSyncWorker>()
            .setConstraints(constraints)
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(
            "attendance_sync_immediate",
            ExistingWorkPolicy.KEEP,
            request
        )
    }
}

/** Minimal SharedPreferences helpers — swap for your own auth/session module. */
object AuthTokenStore {
    fun getToken(context: Context): String? =
        context.getSharedPreferences("attendance_prefs", Context.MODE_PRIVATE)
            .getString("auth_token", null)
}

object SyncPrefs {
    private const val PREFS = "attendance_sync_prefs"
    private const val KEY_LAST_SYNC = "last_embedding_sync_epoch_ms"

    fun getLastEmbeddingSync(context: Context): Long =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(KEY_LAST_SYNC, 0L)

    fun setLastEmbeddingSync(context: Context, value: Long) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putLong(KEY_LAST_SYNC, value).apply()
    }
}
