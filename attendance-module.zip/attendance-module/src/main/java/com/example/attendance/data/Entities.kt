package com.example.attendance.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import androidx.room.TypeConverters

/**
 * Cached copy of each employee's enrolled embedding(s), synced down from the
 * Postgres+pgvector backend so 1:N matching can happen fully offline on-device.
 * Store 2-3 embeddings per employee (different angles/lighting) for robustness;
 * this table allows multiple rows per employeeId.
 */
@Entity(tableName = "employee_embeddings", primaryKeys = ["employeeId", "embeddingSlot"])
@TypeConverters(FloatArrayConverter::class)
data class EmployeeEmbedding(
    val employeeId: String,
    val embeddingSlot: Int,      // 0,1,2... for multiple enrolled samples per person
    val employeeName: String,
    val embedding: FloatArray,
    val updatedAtEpochMs: Long
)

/**
 * A locally-recorded attendance mark, queued for sync. Written immediately
 * on-device (offline-first) regardless of connectivity; WorkManager drains
 * this table to the backend.
 */
@Entity(tableName = "attendance_records")
data class AttendanceRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val employeeId: String,
    val employeeName: String,
    val matchConfidence: Double,
    val eventType: String,          // "CHECK_IN" | "CHECK_OUT"
    val capturedAtEpochMs: Long,
    val latitude: Double,
    val longitude: Double,
    val locationAccuracyMeters: Float,
    val siteId: String?,
    val livenessScore: Float,
    val deviceId: String,
    val photoLocalPath: String?,    // optional evidence photo, stored locally (see privacy note in README)
    val synced: Boolean = false,
    val syncAttempts: Int = 0,
    val lastSyncErrorMessage: String? = null
)

class FloatArrayConverter {
    @TypeConverter
    fun fromFloatArray(value: FloatArray): String = value.joinToString(",")

    @TypeConverter
    fun toFloatArray(value: String): FloatArray =
        value.split(",").filter { it.isNotBlank() }.map { it.toFloat() }.toFloatArray()
}
