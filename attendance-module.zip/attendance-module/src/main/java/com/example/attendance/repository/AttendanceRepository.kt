package com.example.attendance.repository

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import com.example.attendance.data.AttendanceDatabase
import com.example.attendance.data.AttendanceRecord
import com.example.attendance.detection.YuNetFaceDetector
import com.example.attendance.liveness.LivenessDetector
import com.example.attendance.location.GeofenceLocationValidator
import com.example.attendance.location.GeofenceSite
import com.example.attendance.location.LocationCheckResult
import com.example.attendance.recognition.SFaceRecognizer
import com.example.attendance.sync.AttendanceSyncScheduler
import com.example.attendance.util.AttendanceConfig
import com.example.attendance.util.DeviceIntegrityGuard
import com.example.attendance.util.ImageUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

sealed class AttendanceResult {
    data class Success(
        val employeeId: String,
        val employeeName: String,
        val confidence: Double,
        val recordId: Long,
        val elapsedMs: Long
    ) : AttendanceResult()

    data class NoFaceDetected(val reason: String) : AttendanceResult()
    data class LivenessFailed(val realScore: Float) : AttendanceResult()
    data class NoMatch(val bestScore: Double) : AttendanceResult()
    data class LocationRejected(val reason: String) : AttendanceResult()
    data class OutsideGeofence(val distanceMeters: Float, val nearestSiteName: String?) : AttendanceResult()
    data class DeviceFlagged(val reason: String) : AttendanceResult()
    data class Error(val throwable: Throwable) : AttendanceResult()
}

/**
 * Single-tap, single-shot attendance pipeline, tuned to resolve in ~1 second:
 *
 *  - ONE frame in, one decision out — no continuous scanning loop, no
 *    multi-frame voting. The caller (FaceCaptureActivity) grabs exactly one
 *    frame at the moment the user taps Check In / Check Out.
 *  - Liveness is PASSIVE only (single-frame Fourier-spectrum spoof check).
 *    No blink/head-turn/smile prompt, no waiting on the user to move.
 *  - Location is NOT fetched here. GeofenceLocationValidator keeps a
 *    continuously pre-warmed fix cached from the moment the screen opened,
 *    so the geofence check below is an instant in-memory comparison, not a
 *    GPS wait — the single biggest thing that would otherwise blow the
 *    1-second budget.
 *
 * Call startPrewarm()/stopPrewarm() (see below) around the capture screen's
 * lifecycle so the location cache is warm before the first tap.
 */
class AttendanceRepository(private val context: Context) : AutoCloseable {

    private val detector = YuNetFaceDetector(context)
    private val recognizer = SFaceRecognizer(context)
    private val liveness = LivenessDetector(context)
    private val locationValidator = GeofenceLocationValidator(context)
    private val db = AttendanceDatabase.getInstance(context)

    /** Call once when the capture screen opens (before the user can tap Check In/Out). */
    fun startPrewarm() = locationValidator.startContinuousUpdates()

    /** Call when the capture screen closes. */
    fun stopPrewarm() = locationValidator.stopContinuousUpdates()

    suspend fun markAttendance(
        frame: Bitmap,
        approvedSites: List<GeofenceSite>,
        eventType: String, // "CHECK_IN" | "CHECK_OUT"
        enforceGeofence: Boolean = true,
        blockOnRootedDevice: Boolean = false
    ): AttendanceResult = withContext(Dispatchers.Default) {
        val startedAt = System.currentTimeMillis()
        try {
            if (blockOnRootedDevice && DeviceIntegrityGuard.isDeviceSuspicious(context)) {
                return@withContext AttendanceResult.DeviceFlagged("Device appears rooted/tampered")
            }

            // Geofence check first: instant (pre-warmed cache), so fail fast
            // before spending time on the ML pipeline if the user is clearly
            // in the wrong place.
            var lat = 0.0; var lon = 0.0; var accuracy = 0f; var siteId: String? = null
            if (enforceGeofence) {
                when (val locResult = locationValidator.validateAgainstSitesFast(approvedSites)) {
                    is LocationCheckResult.Inside -> {
                        lat = locResult.location.latitude
                        lon = locResult.location.longitude
                        accuracy = locResult.location.accuracy
                        siteId = locResult.site.siteId
                    }
                    is LocationCheckResult.Outside -> return@withContext AttendanceResult.OutsideGeofence(
                        locResult.distanceMeters, locResult.nearestSite?.name
                    )
                    is LocationCheckResult.Rejected -> return@withContext AttendanceResult.LocationRejected(locResult.reason)
                }
            }

            // 1) Detect (single frame, single pass)
            val faces = detector.detect(frame)
            val face = faces.maxByOrNull { it.box.width() * it.box.height() }
                ?: return@withContext AttendanceResult.NoFaceDetected("No face found in frame")

            // 2) Liveness — PASSIVE only, single frame, no motion required
            val rawCrop = ImageUtils.cropWithMargin(frame, face.box, marginRatio = 0.3f)
            val livenessResult = liveness.check(rawCrop)
            if (!livenessResult.isReal) {
                return@withContext AttendanceResult.LivenessFailed(livenessResult.realScore)
            }

            // 3) Align + embed
            val aligned = ImageUtils.alignFace(frame, face.landmarks, AttendanceConfig.RECOGNITION_INPUT_SIZE)
            val probeEmbedding = recognizer.embed(aligned)

            // 4) Match against offline-cached enrolled embeddings (1:N)
            val cached = db.attendanceDao().getAllEmbeddings()
            var bestEmployeeId: String? = null
            var bestEmployeeName: String? = null
            var bestScore = -1.0
            for (entry in cached) {
                val score = recognizer.similarity(probeEmbedding, entry.embedding)
                if (score > bestScore) {
                    bestScore = score
                    bestEmployeeId = entry.employeeId
                    bestEmployeeName = entry.employeeName
                }
            }
            if (bestEmployeeId == null || bestScore < AttendanceConfig.MATCH_COSINE_THRESHOLD) {
                return@withContext AttendanceResult.NoMatch(bestScore)
            }

            // 5) Persist offline (works with zero connectivity) and schedule sync
            val record = AttendanceRecord(
                employeeId = bestEmployeeId,
                employeeName = bestEmployeeName ?: "",
                matchConfidence = bestScore,
                eventType = eventType,
                capturedAtEpochMs = System.currentTimeMillis(),
                latitude = lat,
                longitude = lon,
                locationAccuracyMeters = accuracy,
                siteId = siteId,
                livenessScore = livenessResult.realScore,
                deviceId = DeviceIntegrityGuard.stableDeviceId(context),
                photoLocalPath = null
            )
            val id = db.attendanceDao().insertRecord(record)
            AttendanceSyncScheduler.triggerImmediateSync(context)

            val elapsed = System.currentTimeMillis() - startedAt
            if (elapsed > AttendanceConfig.PIPELINE_TIME_BUDGET_MS) {
                Log.w("AttendanceRepository", "Pipeline took ${elapsed}ms, over the ${AttendanceConfig.PIPELINE_TIME_BUDGET_MS}ms budget")
            }
            AttendanceResult.Success(bestEmployeeId, bestEmployeeName ?: "", bestScore, id, elapsed)
        } catch (t: Throwable) {
            AttendanceResult.Error(t)
        }
    }

    override fun close() {
        detector.close()
        recognizer.close()
        liveness.close()
        locationValidator.stopContinuousUpdates()
    }
}
