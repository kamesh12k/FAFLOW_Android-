package com.example.attendance.util

/**
 * Central config for the attendance module. Tune these without touching
 * business logic. Ship the three ONNX models below in assets/models/.
 *
 *  - yunet.onnx                     -> face detection (YuNet, OpenCV Zoo)
 *  - sface.onnx                     -> face recognition embeddings (SFace)
 *  - anti_spoof_fourier.onnx        -> liveness (Silent-Face-Anti-Spoofing export)
 */
object AttendanceConfig {

    // ---- Model assets ----
    const val ASSET_YUNET = "models/yunet.onnx"
    const val ASSET_SFACE = "models/sface.onnx"
    const val ASSET_ANTISPOOF = "models/anti_spoof_fourier.onnx"

    // ---- Detection ----
    const val DETECT_INPUT_W = 320
    const val DETECT_INPUT_H = 320
    const val DETECT_SCORE_THRESHOLD = 0.85f
    const val DETECT_NMS_THRESHOLD = 0.3f
    const val DETECT_TOP_K = 50

    // ---- Recognition ----
    const val RECOGNITION_INPUT_SIZE = 112 // SFace expects 112x112 aligned crop
    const val EMBEDDING_DIM = 128

    /** Cosine similarity threshold above which two faces are considered a match.
     *  0.363 is OpenCV Zoo's published SFace threshold for the "cosine" metric;
     *  tighten (e.g. 0.45-0.55) for stricter 1:N attendance matching. */
    const val MATCH_COSINE_THRESHOLD = 0.45

    // ---- Liveness ----
    const val LIVENESS_INPUT_SIZE = 80
    const val LIVENESS_REAL_THRESHOLD = 0.90f

    // ---- Geofence ----
    const val DEFAULT_GEOFENCE_RADIUS_METERS = 100f
    /** Location is pre-warmed continuously (see GeofenceLocationValidator), so this
     *  is how old the CACHED fix may be at tap-time, not a "wait this long" budget. */
    const val LOCATION_MAX_AGE_MS = 30 * 1000L     // reject cached fixes older than 30s
    const val LOCATION_MIN_ACCURACY_METERS = 50f   // reject fixes with worse accuracy than this
    /** Interval for the continuous background location updates that keep
     *  cachedLocation fresh so tap-time validation is instant (no GPS wait). */
    const val LOCATION_UPDATE_INTERVAL_MS = 5000L

    // ---- Latency budget (single-tap check-in/out) ----
    // Target: full pipeline (capture frame -> detect -> liveness -> align ->
    // embed -> match -> geofence -> persist) completes in ~1 second on a
    // mid-range device. Location is NOT on this critical path (pre-warmed).
    // If you're missing budget, in order of biggest wins:
    //   1. Confirm ONNX Runtime is using NNAPI/GPU execution provider, not pure CPU.
    //   2. Lower DETECT_INPUT_W/H (e.g. 240x240) — detection dominates latency.
    //   3. Make sure only ONE frame is processed per tap, not a continuous stream.
    const val PIPELINE_TIME_BUDGET_MS = 1000L

    // ---- Sync ----
    const val SYNC_BATCH_SIZE = 50
    const val SYNC_RETRY_BACKOFF_MIN = 15L
}
