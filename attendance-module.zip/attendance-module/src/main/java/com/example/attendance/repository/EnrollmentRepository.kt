package com.example.attendance.repository

import android.content.Context
import android.graphics.Bitmap
import com.example.attendance.data.AttendanceDatabase
import com.example.attendance.data.EmployeeEmbedding
import com.example.attendance.detection.YuNetFaceDetector
import com.example.attendance.recognition.SFaceRecognizer
import com.example.attendance.util.AttendanceConfig
import com.example.attendance.util.ImageUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

sealed class EnrollmentResult {
    data class Success(val embedding: FloatArray) : EnrollmentResult()
    object NoFaceDetected : EnrollmentResult()
    object MultipleFacesDetected : EnrollmentResult()
    data class Error(val throwable: Throwable) : EnrollmentResult()
}

/**
 * Use during employee onboarding: capture 2-3 clear, well-lit shots per
 * person (different slight angles) and enroll each as a separate
 * embeddingSlot for the same employeeId. This both improves match recall
 * and lets the on-device cache work fully offline once synced down.
 *
 * In production, enrollment normally happens server-side (HR admin console)
 * and the resulting embeddings sync down via AttendanceSyncWorker — this
 * class is for an on-device/kiosk enrollment flow if you need one.
 */
class EnrollmentRepository(private val context: Context) : AutoCloseable {

    private val detector = YuNetFaceDetector(context)
    private val recognizer = SFaceRecognizer(context)
    private val db = AttendanceDatabase.getInstance(context)

    suspend fun enroll(
        frame: Bitmap,
        employeeId: String,
        employeeName: String,
        embeddingSlot: Int
    ): EnrollmentResult = withContext(Dispatchers.Default) {
        try {
            val faces = detector.detect(frame)
            if (faces.isEmpty()) return@withContext EnrollmentResult.NoFaceDetected
            if (faces.size > 1) return@withContext EnrollmentResult.MultipleFacesDetected

            val face = faces[0]
            val aligned = ImageUtils.alignFace(frame, face.landmarks, AttendanceConfig.RECOGNITION_INPUT_SIZE)
            val embedding = recognizer.embed(aligned)

            db.attendanceDao().upsertEmbeddings(listOf(
                EmployeeEmbedding(
                    employeeId = employeeId,
                    embeddingSlot = embeddingSlot,
                    employeeName = employeeName,
                    embedding = embedding,
                    updatedAtEpochMs = System.currentTimeMillis()
                )
            ))

            // TODO: also push this embedding to your backend (pgvector) so
            // other devices pick it up on their next AttendanceSyncWorker run:
            //   ApiClient.create { token }.uploadEmbedding(...)

            EnrollmentResult.Success(embedding)
        } catch (t: Throwable) {
            EnrollmentResult.Error(t)
        }
    }

    override fun close() {
        detector.close()
        recognizer.close()
    }
}
