package com.example.attendance.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AttendanceDao {

    // ---- Employee embeddings (offline face cache) ----

    @Query("SELECT * FROM employee_embeddings")
    suspend fun getAllEmbeddings(): List<EmployeeEmbedding>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertEmbeddings(embeddings: List<EmployeeEmbedding>)

    @Query("DELETE FROM employee_embeddings WHERE employeeId = :employeeId")
    suspend fun deleteEmbeddingsForEmployee(employeeId: String)

    @Query("DELETE FROM employee_embeddings")
    suspend fun clearAllEmbeddings()

    // ---- Attendance records (offline queue) ----

    @Insert
    suspend fun insertRecord(record: AttendanceRecord): Long

    @Query("SELECT * FROM attendance_records WHERE synced = 0 ORDER BY capturedAtEpochMs ASC LIMIT :limit")
    suspend fun getUnsyncedBatch(limit: Int): List<AttendanceRecord>

    @Update
    suspend fun updateRecord(record: AttendanceRecord)

    @Query("UPDATE attendance_records SET synced = 1 WHERE id = :id")
    suspend fun markSynced(id: Long)

    @Query("""
        UPDATE attendance_records
        SET syncAttempts = syncAttempts + 1, lastSyncErrorMessage = :error
        WHERE id = :id
    """)
    suspend fun recordSyncFailure(id: Long, error: String)

    @Query("SELECT * FROM attendance_records ORDER BY capturedAtEpochMs DESC")
    fun observeAllRecords(): Flow<List<AttendanceRecord>>

    @Query("SELECT COUNT(*) FROM attendance_records WHERE synced = 0")
    fun observePendingCount(): Flow<Int>

    @Query("""
        SELECT * FROM attendance_records
        WHERE employeeId = :employeeId
        ORDER BY capturedAtEpochMs DESC LIMIT 1
    """)
    suspend fun getLastRecordForEmployee(employeeId: String): AttendanceRecord?
}
