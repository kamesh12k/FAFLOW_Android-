package com.example.attendance.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [EmployeeEmbedding::class, AttendanceRecord::class],
    version = 1,
    exportSchema = true
)
abstract class AttendanceDatabase : RoomDatabase() {

    abstract fun attendanceDao(): AttendanceDao

    companion object {
        @Volatile private var INSTANCE: AttendanceDatabase? = null

        fun getInstance(context: Context): AttendanceDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AttendanceDatabase::class.java,
                    "attendance.db"
                )
                    // Embeddings are biometric data — encrypt the DB file at rest.
                    // Wire in SQLCipher (net.zetetic:android-database-sqlcipher) here
                    // if your compliance review requires DB-level encryption in
                    // addition to full-disk encryption. Left as a plain Room DB
                    // by default to keep this module dependency-light.
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
    }
}
