package com.example.attendance.liveness

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.graphics.Bitmap
import com.example.attendance.util.AttendanceConfig
import java.nio.FloatBuffer

data class LivenessResult(val isReal: Boolean, val realScore: Float)

/**
 * Wraps a Silent-Face-Anti-Spoofing model (Fourier-spectrum supervised),
 * exported to ONNX, to classify a face crop as real / 2D-spoof / 3D-spoof.
 * Expects the SAME crop region as detection (not the 112x112 aligned
 * recognition crop) resized to LIVENESS_INPUT_SIZE.
 *
 * NOTE: this is a single-frame, PASSIVE check — no blink/head-turn/smile is
 * required from the user, which is what keeps the whole check-in flow to
 * ~1 second. `randomChallenge()` below is an OPTIONAL hook for teams that
 * later want a stronger active-liveness step; AttendanceRepository does not
 * call it by default and nothing in the default flow asks the user to move.
 * This is a helpful anti-spoof signal, not a silver bullet — if your threat
 * model needs stronger assurance later, that's the trade-off to revisit.
 */
class LivenessDetector(context: Context) : AutoCloseable {

    private val env = OrtEnvironment.getEnvironment()
    private val session: OrtSession

    init {
        val modelBytes = context.assets.open(AttendanceConfig.ASSET_ANTISPOOF).readBytes()
        val options = OrtSession.SessionOptions().apply { setIntraOpNumThreads(4) }
        session = env.createSession(modelBytes, options)
    }

    fun check(faceCrop: Bitmap): LivenessResult {
        val size = AttendanceConfig.LIVENESS_INPUT_SIZE
        val resized = Bitmap.createScaledBitmap(faceCrop, size, size, true)
        val inputName = session.inputNames.iterator().next()
        val buffer = bitmapToChwFloatBuffer(resized)
        val tensor = OnnxTensor.createTensor(env, buffer, longArrayOf(1, 3, size.toLong(), size.toLong()))

        tensor.use {
            session.run(mapOf(inputName to it)).use { results ->
                @Suppress("UNCHECKED_CAST")
                val logits = (results[0].value as Array<FloatArray>)[0]
                val probs = softmax(logits)
                // Class layout for the common Silent-Face export: [0]=spoof, [1]=real (2-class)
                // or [0]=2D-spoof, [1]=3D-spoof, [2]=real (3-class). Handle both.
                val realScore = if (probs.size >= 3) probs[2] else probs[1]
                return LivenessResult(realScore >= AttendanceConfig.LIVENESS_REAL_THRESHOLD, realScore)
            }
        }
    }

    /** Simple enum you can use to drive an active liveness challenge UI
     *  (e.g. "blink now" / "turn your head left") as a second factor on
     *  top of the passive Fourier-spectrum check above. */
    enum class Challenge { BLINK, TURN_LEFT, TURN_RIGHT, SMILE }
    fun randomChallenge(): Challenge = Challenge.entries.random()

    private fun softmax(logits: FloatArray): FloatArray {
        val max = logits.max()
        val exps = FloatArray(logits.size) { Math.exp((logits[it] - max).toDouble()).toFloat() }
        val sum = exps.sum()
        return FloatArray(logits.size) { exps[it] / sum }
    }

    private fun bitmapToChwFloatBuffer(bitmap: Bitmap): FloatBuffer {
        val w = bitmap.width
        val h = bitmap.height
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)

        val buffer = FloatBuffer.allocate(3 * w * h)
        val bPlane = FloatArray(w * h)
        val gPlane = FloatArray(w * h)
        val rPlane = FloatArray(w * h)
        for (i in pixels.indices) {
            val p = pixels[i]
            rPlane[i] = (((p shr 16) and 0xFF) / 255f)
            gPlane[i] = (((p shr 8) and 0xFF) / 255f)
            bPlane[i] = ((p and 0xFF) / 255f)
        }
        buffer.put(bPlane); buffer.put(gPlane); buffer.put(rPlane)
        buffer.rewind()
        return buffer
    }

    override fun close() {
        session.close()
    }
}
